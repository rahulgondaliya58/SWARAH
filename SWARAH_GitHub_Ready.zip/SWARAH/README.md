# SWARAH - Personal Milestone Tracker App

This is a Flutter application to store personal details and track milestones with both offline (SQLite) and online (Firebase) capabilities.

## Features
- Personal Info Storage (Name, DOB, Email, etc.)
- Milestone Entry (Title, Description, Date, Category, Image)
- Local storage using SQLite (coming next)
- Firebase ready for Auth and Cloud Sync (Phase 2)

## Getting Started
1. Clone the repo or upload it to GitHub
2. Run `flutter pub get`
3. Use `flutter run` to launch or `flutter build apk --release` to generate APK
