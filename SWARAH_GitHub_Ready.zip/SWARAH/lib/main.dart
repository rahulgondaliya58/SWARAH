
import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(SwarahApp());
}

class SwarahApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SWARAH',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: LoginScreen(),
    );
  }
}
