
import 'package:flutter/material.dart';

class MilestoneScreen extends StatelessWidget {
  const MilestoneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Milestone')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(decoration: InputDecoration(labelText: 'Title')),
            TextField(decoration: InputDecoration(labelText: 'Description')),
            TextField(decoration: InputDecoration(labelText: 'Date')),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(labelText: 'Category'),
              items: ['Career', 'Health', 'Finance', 'Personal', 'Other']
                  .map((label) => DropdownMenuItem(
                        child: Text(label),
                        value: label,
                      ))
                  .toList(),
              onChanged: (_) {},
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text('Save Milestone'),
            ),
          ],
        ),
      ),
    );
  }
}
